<?php /* Template Name: Home */ ?>
<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
<div id="mainHome">
	  <div id="slider">
		<a href="#" class="control_next">>></a>
		<a href="#" class="control_prev"><<</a>
		<ul>
			<li>SLIDE 1<img src="images/blog1.jpg" /></li>
			<li style="background: #aaa;">SLIDE 2<img src="images/blog2.jpg"</li>
			<li>SLIDE 3</li>
			<li style="background: #aaa;">SLIDE 4</li>
		</ul>  
	</div>
	<div class="slider_option">
		<input type="checkbox" id="checkbox">
		<label for="checkbox">Autoplay Slider</label>
	</div>


			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/page/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>



<?php get_footer();
