<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link href='http://fonts.googleapis.com/css?family=Lato:300,700,300italic,700italic' rel='stylesheet' type='text/css'>
	
	
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!-- AM I DOING STUFF? -->

	<!--<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentyseventeen' ); ?></a>-->

	<header>
		<h1><a href="<?php home_url('/') ?>"><?php bloginfo('name')?></a></h1>
		<h2><?php bloginfo('description')?></h2>
		<form action="/" method="get">
			<input class="fr" type="search" results="5" name="s" placeholder="Search..." value="<?php the_search_query(); ?>" />
		</form>

		<?php if ( has_nav_menu( 'top' ) ) : ?>
			
					<?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
				
		<?php endif; ?>

	</header><!-- #masthead -->

	<?php
	// If a regular post or page, and not the front page, show the featured image.
	if ( has_post_thumbnail() && ( is_single() || ( is_page() && ! twentyseventeen_is_frontpage() ) ) ) :
		echo '<div class="single-featured-image-header">';
		the_post_thumbnail( 'twentyseventeen-featured-image' );
		echo '</div><!-- .single-featured-image-header -->';
	endif;
	?>

	<div class="site-content-contain">
		<div id="content" class="site-content">
