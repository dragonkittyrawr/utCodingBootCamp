<footer>
  <p>Copyright 2016 &copy;</p>
</footer>
