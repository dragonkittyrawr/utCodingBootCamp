<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Hacking w/ PHP</a>
    </div><!-- /.navbar-header-->
  </div><!--/.container-fluid -->
</nav>
